# Ballast Guidance Surface Maintenance

Use this reference when changing the Ballast planner guidance surface. The audience is repo maintainers, not agents running a planner task.

## Surface Split

Ballast ships three distinct guidance surfaces. Each piece of doctrine has exactly one home — duplicate copies are drift waiting to happen.

### Skill body (this directory)

- `src/ballast-operations/SKILL.md` — sole canonical copy. Triggering description + resource/tool router + irreducible rules.
- `src/ballast-operations/references/skill-maintenance.md` — this file (maintainer-only).
- `src/ballast-operations/evals/` — assertions and trigger queries.

The skill body is intentionally thin. It answers two questions: *should I be here?* and *what should I load next?* It is not the home for workflow doctrine.

### MCP resources (`obto://ballast/*`)

Shipped under `src/mcp_resources/*.mjs` and served by the live OBTO platform after publish.

- `obto://ballast/start-here` — orientation. Entry point + resource routing decision table.
- `obto://ballast/ops-handbook` — workflow doctrine, persistence guardrails, acceptance discipline, anti-patterns.
- `obto://ballast/versioning-playbook` — concurrency mechanics, version-field map, multi-step safe sequences, conflict recovery.
- `obto://ballast/project-intake` — five-signal protocol, synthesis checklist, brief format, common intake failures.
- `obto://ballast/tool-reference` — tool inventory (all tools `ballast_`-prefixed), recommended chained sequences.

Doctrine that an MCP-only client should be able to load belongs in a resource, not a skill reference.

### MCP prompts (`src/mcp_prompts/*.mjs`)

Slim orchestration shells. Each prompt points at the relevant resource for doctrine and focuses on the call sequence against the prompt's arguments.

- `plan-project.mjs` — shipped and live (registered as the `ballast_plan_project` prompt, `isActive`, app `ballast`). Points to `obto://ballast/project-intake` and `obto://ballast/tool-reference`.
- `close-task.mjs` — shipped and live (registered as the `ballast_close_task` prompt, `isActive`, app `ballast`). Points to `obto://ballast/versioning-playbook` § "Close a task safely".
- `obto-developer-sop` — registered on the OBTO platform prompt registry (platform-side; not authored in this repo). For OBTO artifact/deployment work, not routine planner workflows. It is platform-scoped and is intentionally **not** cross-linked from the planner resources or this skill — planner doctrine stops at the OBTO deployment boundary.

Prompts must not re-embed doctrine. If a prompt grows past ~60 lines of body text, the doctrine has leaked back in — extract it to a resource.

### Tool guidance (`src/mcp_tools/planner-mcp-guidance.mjs`)

Per-tool description, `callWhen`, `avoidWhen`, examples, and `inputHints`. This surface answers *should I call THIS tool for THIS user input?* — not broader workflow doctrine. Workflow doctrine belongs in resources.

## Maintenance Rules

- **One home per piece of doctrine.** If two surfaces say the same thing, the resource wins. Delete the duplicate.
- **Namespace is `obto://ballast/*`.** The `obto://ai-planner/*` namespace was retired in the 2026-05-08 resource migration (commit `2e065c2`) — in the repo. NOTE: the live platform may still surface `obto://ai-planner/*` as baked-in resources, so retirement is complete in-repo but not necessarily on the platform; treat any platform-exposed `obto://ai-planner/*` as superseded. Grep for stale `obto://ai-planner/` or `planner://guide/` references when touching this surface.
- **Skill body stays under ~120 lines.** If it grows, push content into a resource and replace it with a pointer.
- **Prompts stay under ~80 lines of body.** If they grow, the doctrine has leaked in.
- **`src/` is the source of truth.** Older mirrors under `obto_code/resources/` may exist for historical reasons — do not author there. The architecture doc references `obto_code/` for the resource surface but the live source is `src/mcp_resources/`.
- **Trigger queries stay narrow.** The skill should activate on Ballast planner workflow problems, not generic coding or PM tasks.

## Validation Sequence

Run after any change to the guidance surface:

1. Edit the relevant source files under `src/mcp_resources/`, `src/mcp_prompts/`, `src/mcp_tools/`, or `src/ballast-operations/`.
2. `npm run target`
3. `npm run render` (or `npm run render:dry-run` to validate without writing).
4. `npm run mcp-tools:render` when tool descriptions, bindings, or guide-resource references changed.
5. `npm run verify:mcp-tools`.
6. `npm run verify:live-response-shapes` when response wording or status-report guidance changed.
7. `npm run verify:live-smoke` after every publish. Run `verify:live-smoke-then-concurrency` when versioning semantics or safe-sequencing guidance changed.
8. `npm run verify:live-admin` when status-report or admin-facing guidance changed.
9. Grep `src/ballast-operations/`, `src/mcp_resources/`, `src/mcp_prompts/`, `src/mcp_tools/`, and `obto_code/` for stale URIs (`obto://ai-planner/`, `planner://guide/`, `obto://platform/guide/`) and stale reference paths (`references/operations-reference.md`, `references/versioning-playbook.md`, `references/project-intake.md`). The `obto://platform/guide/*` namespace was retired from the planner surface in the prefix/harmonization pass — agent-facing planner resources must not reference it.
10. Grep the same surfaces for unprefixed planner tool names. Every planner tool mention must use the live `ballast_` prefix (e.g. `ballast_get_next_actions`, not `get_next_actions`). The prompts take the same prefix — `ballast_plan_project`, `ballast_close_task`, `ballast_clarify_detect_gaps` — because mcp_prompts is unique on (domain, name) and a bare name collides for any tenant that includes two planner apps at once. This governs the **shipped guidance surface** (resources, skill, tool/prompt descriptions); it deliberately does NOT apply to the `evals/` assertion rubrics, which accept bare tool names on purpose because they grade an agent's free-form prose response, not the shipped surface.

## Iteration Signals

Watch for these in agent behavior — they indicate the guidance surface is working:

- Agents cite the shipped resource URIs (`obto://ballast/*`) instead of restating doctrine from memory.
- Agents reach for tools, not invented guide URIs, when loading live project or task state.
- Agents keep planner doctrine separate from OBTO artifact/deployment work — they recognize the boundary and hand platform mechanics to the OBTO tooling instead of inventing planner doctrine for it.
- Agents use the correct version field for each mutation and stop dual-writing durable planner state elsewhere.
- Agents do not paste the five-signal intake protocol into chat — they reference `obto://ballast/project-intake` and follow it.

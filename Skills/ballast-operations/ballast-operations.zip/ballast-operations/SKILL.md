---
name: ballast-operations
description: Use this skill whenever the user is working with Ballast — VibeForge's durable, MCP-native execution layer for spec-driven development on OBTO — and the agent needs to be routed to the right shipped resource and tool family before acting. Trigger even when the user does not say "Ballast" explicitly but is asking about project state, ready work, blockers, task trees, critical path, acceptance criteria, version_conflict, expectedVersion or expectedVersions, planner persistence, or how to continue an existing planner project safely. Make sure to use this skill whenever the user mentions resuming a planner project, planning a new one, decomposing tasks, closing tasks, or hits a planner concurrency error — even if they don't explicitly name the skill. Do not use for generic coding, generic PM advice, or plain status writing that does not depend on Ballast resources or planner tools.
compatibility: Designed for agents that can access the Ballast planner MCP surface (tools + resources + prompts) shipped on OBTO.
metadata:
  owner: nagual69/Ballast
  surface: ballast-operations
  version: "5"
---

# Ballast Operations

Ballast is the durable system of record for project state. This skill is a router — it tells you which shipped resource to load and which tool family to use. The doctrine lives in the resources, not here.

If another todo or checklist tool is available alongside Ballast, use it only for disposable session scratch. Do not split durable planner state across systems.

## Resource Routing

Always start with `obto://ballast/start-here`. Then load the resource that matches what you are about to do:

| Situation | Resource |
|---|---|
| Orientation, first contact with a Ballast project | `obto://ballast/start-here` |
| Sequencing work, persistence guardrails, acceptance verification | `obto://ballast/ops-handbook` |
| Any mutation, multi-step write sequence, or `version_conflict` recovery | `obto://ballast/versioning-playbook` |
| Bootstrapping a new project from a fresh request | `obto://ballast/project-intake` |
| Choosing which tool to call, or chaining tools into a workflow | `obto://ballast/tool-reference` |

The handbook is the most commonly useful follow-on. Load the others only when their situation applies — they are not on the default read path.

These are dynamic MCP resources. If your client's resource list is empty or does not show them, call `obto_list_mcp_resources` (or read them by URI directly) — do not fall back to guessed `planner://` guide URIs.

OBTO artifact, route, host, and deployment work is outside this skill. When a task crosses into platform mechanics, handle it with the OBTO platform tooling rather than planner doctrine — these resources do not cover it.

## Tool Routing

Project and task state is tool-driven, not resource-driven. Load only the narrowest useful state:

- Unknown project: `ballast_list_projects`
- Known project overview: `ballast_get_project` or `ballast_get_project_summary`
- Ready work: `ballast_get_next_actions`
- Blocking analysis: `ballast_get_blocked_tasks` or `ballast_get_critical_path`
- One task: `ballast_get_task`
- Fresh concurrency tokens only: `ballast_get_record_versions`
- Reusable status artifact: `ballast_export_project_status_report`

For the full tool inventory (all tools are `ballast_`-prefixed) and chained sequences (resume, plan, close, rebalance, status), read `obto://ballast/tool-reference`. For exact version fields and safe sequences, read `obto://ballast/versioning-playbook`.

## Optional Prompts

When the connected client exposes them:

- `ballast_plan_project` — orchestrates intake → ballast_create_project → tasks with criteria → dependency setup → critical-path review. Points to `obto://ballast/project-intake` for the protocol.
- `ballast_close_task` — orchestrates the version-safe close sequence. Points to `obto://ballast/versioning-playbook` § "Close a task safely".

Prompts do not carry doctrine. Read the linked resource before acting on the prompt.

## Irreducible Rules

These are the rules that need to be in context every turn, not loaded on demand:

- **Ballast is the system of record.** Do not dual-write durable planner state into another todo tool and sync back later.
- **Treat `version_conflict` as a state conflict, not a transport failure.** Re-read before retrying.
- **The version field varies by tool.** Do not assume `expectedVersion` works for everything. `ballast_bulk_update_tasks` uses `expectedVersions`. `ballast_decompose_task` uses `parentExpectedVersion`. Dependency mutations use both `fromTaskExpectedVersion` and `toTaskExpectedVersion`. See `obto://ballast/versioning-playbook` § Version Field Map.
- **Append-only writes do NOT bump the parent version.** `ballast_set_acceptance_criteria`, `ballast_add_decision`, and `ballast_add_task_files` take NO version field and write blindly without advancing the parent task version. The version-bearing context writes — `ballast_check_acceptance_criterion` (`expectedTaskVersion`) and `ballast_update_implementation_notes` (`expectedVersion`) — accept an OPTIONAL version field and DO advance the parent version, so carry forward the `taskVersion` they return for the next conflict-checked write (or refresh with `ballast_get_record_versions` if you didn't keep it).
- **Use `ballast_transition_task`, not chat narration**, for status changes.
- **Use `ballast_add_decision` and `ballast_update_implementation_notes` only for durable content.** Never for internal reasoning, next-tool reminders, or self-narration.
- **Never close a task with unverified criteria.** Run `ballast_check_acceptance_criterion` on each one before `ballast_transition_task` to `done`.
- **The canonical resource namespace is `obto://ballast/*`.** Prefer it. The `obto://ai-planner/*` and `planner://guide/*` namespaces were superseded in the 2026-05-08 migration; if your client still exposes them, treat them as superseded and do not load them.

## Safe close in brief

The highest-stakes sequence, inlined for resource-blind clients (full version: `obto://ballast/versioning-playbook` § "Close a task safely"):

1. `ballast_get_task` — capture the current version + `verificationStatus`.
2. For each unmet criterion: `ballast_check_acceptance_criterion` with `expectedTaskVersion`, carrying the returned `taskVersion` forward between checks (these DO bump).
3. Optional `ballast_add_decision` / `ballast_add_task_files` for durable closure context — append-only, no version, no refresh.
4. If you used `ballast_update_implementation_notes`, it DOES bump — carry its returned `taskVersion`.
5. `ballast_transition_task` to `done` with the freshest `expectedVersion`; if `verificationStatus` is not `passing`, stop and surface the unmet criteria.

## When State Drift Surfaces

If a tool call produces an unexpected entity, duplicates a planned step, or leaves the current step unclear, stop mutating planner state. Re-read with `ballast_get_record_versions` or `ballast_get_task`. Ask the user before attempting cleanup or recovery writes. Cleanup is not a scratchpad — do not use `ballast_add_decision`, `ballast_add_task_files`, or `ballast_set_acceptance_criteria` as recovery breadcrumbs.

## For Maintainers

When you change the planner guidance surface — resources, prompts, tool descriptions, or this skill — see `references/skill-maintenance.md` for the canonical inputs, drift hazards, and validation sequence.

## Completion Standard

Before declaring planner work complete:

- Durable state lives in planner tools, not chat-only narration.
- Every meaningful task has acceptance criteria and they have been verified with `ballast_check_acceptance_criterion`.
- The version fields used match what each tool expects.
- No planner notes or decisions were used as scratch space for internal reasoning.
- The relevant verification suite has passed if the planner surface itself changed.
